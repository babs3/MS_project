from geo_schelling_points.server import server

server.launch()
