from rainfall.server import server

server.launch()
