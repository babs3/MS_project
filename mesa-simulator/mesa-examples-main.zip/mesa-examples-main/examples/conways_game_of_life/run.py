from conways_game_of_life.server import server

server.launch(open_browser=True)
